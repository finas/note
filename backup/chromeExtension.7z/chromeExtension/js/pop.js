var vuePop=new Vue({
    el: '#app',
  
    data: {
    	lunchCheck:false,
    	dinnerCheck:false,
        username: '',
        password: '',
        hasLogin:false,
        stateInfo:'',
        eater:''

    },
    created:function(){
    	var savedUserName=this.storage('get','username');
    	var savedPassword=this.storage('get','password');
    	this.username=savedUserName||'';
    	this.password=savedPassword||'';
    	if(this.username&&this.password){
    		this.tryLogin();
    	}
    },
    methods: {
        storage:function(action,key,value){
        	if('get'===action){
	        	return localStorage.getItem(key);
        	}else if('set'===action){
        		return localStorage.setItem(key,value);
        	}
        },
        submit: function() {
        	var typeList=[
        		{
        			type:'午餐',
        			selected:this.lunchCheck
        		},
        		{
        			type:'晚餐',
        			selected:this.dinnerCheck
        		}
        	].filter(function(item){
        		return item.selected;
        	});
        	var that=this;
        	typeList.map(function(item){
	        	that.tryLogin().then(that.tryOrder(item.type));
        	})
        },
        tryLogin:function(){
        	var that=this;
        	var username=that.username,password=that.password;
        	return new Promise(function(resolve,reject){
        		if(that.hasLogin){
        			resolve('ok');
        			return;
        		}
	        	var fData=new FormData();
	        	fData.append('username',username);
	        	fData.append('password',password);
	        	axios({
				    url: 'http://oa.xiaoquan.com:10000/login_auth/',
	        		method 	:'post',
	        		data:fData
	        	}).then(function(xhr){
	        		var isCookie=xhr&&xhr.headers&&xhr.headers.vary;
	        		if(!isCookie){
		        		that.stateInfo+='<div>登录失败</div>';
	        			reject('fail');
	        			return;
	        		}
	        		that.storage('set','username',username);
	        		that.storage('set','password',password);
	        		that.stateInfo+='<div>登录成功</div>';
	        		that.hasLogin=true;
	        		resolve('ok');
	        	});

        	})
        },
        tryOrder:function(type){
    		var that=this;
        	return function(data){
        		var fData=new FormData();
        		fData.append('name',this.eater);
        		fData.append('type',type);
        		axios({
        		    url: 'http://oa.xiaoquan.com:10000/order_form_save/',
        		    data: fData,
        		    method: 'post',
        		    withCredentials: true
        		}).catch(function(error){
        			that.stateInfo+='<div>'+error+'</div>';
        		}).then(function(data) { 
        			that.stateInfo+='<div>'+type+'：'+data.data.msg+"</div>";
        			// $app.append(data.data.msg)
        		});
        	}
        }
    }
});
/*$('.submit').click(()=>{
	try2Order();
});
var try2Order=function(){
	var fData=new FormData();
	fData.append('username',$('input[name=username]').val());
	fData.append('password',$('input[name=password]').val());
	var type='午餐';
	if($('input[name=dinnerCheck]:selected')){
		type='晚餐';
	}
	var order={
		name:$('input[name=eater]').val(),
		type:type
	};
	var $app=$('#app');
	$('#app').append('<div>----------开始登录----------</div>');
	// console.info('----------开始登录----------');
	axios({
	    url: 'http://oa.xiaoquan.com:10000/login_auth/',
	    data: fData,
	    method: 'post',
	}).then(function(xhr) {
		var isCookie=xhr&&xhr.headers&&xhr.headers.vary;
		if(!isCookie){
			$app.append('<div>----------登录失败----------</div>');
			// console.error('----------登录失败----------');
			return;
		}
		$app.append('<div>----------开始订餐----------</div>');
		$app.append('<div>姓名：'+order.name+'，类型：'+order.type+'</div>');
		// console.info('----------开始订餐----------');
		var fData=new FormData();
		fData.append('id','');
		fData.append('name',order.name);
		fData.append('type',order.type);
	    axios({
	        url: 'http://oa.xiaoquan.com:10000/order_form_save/',
	        data: fData,
	        method: 'post',
	        withCredentials: true
	    }).catch((error) => console.error(error)).then((data) => $app.append(data.data.msg));
	}).catch((error) => console.error(error));
}*/